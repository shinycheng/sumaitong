str = 'Winter jacket women high quality down coat female 2020 long slim solid color female Jackets zip fur collar women down Jacket'
print(str.title())